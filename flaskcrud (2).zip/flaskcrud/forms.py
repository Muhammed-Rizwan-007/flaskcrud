from flask_wtf import FlaskForm
from wtforms import StringField, SubmitField
from wtforms.validators import DataRequired, Length, Email, ValidationError
from models import student

class RegistrationForm(FlaskForm):
    name = StringField(
        'Full Name',
        validators=[
            DataRequired(message="Name is required."),
            Length(min=2, max=50, message="Name must be between 2 and 50 characters.")
        ]
    )
    email = StringField(
        'Email Address',
        validators=[
            DataRequired(message="Email is required."),
            Email(message="Please enter a valid email address."),
            Length(max=100)
        ]
    )
    submit = SubmitField('Save')

    def __init__(self, original_email=None, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.original_email = original_email

    def validate_email(self, email):
        if email.data != self.original_email:
            existing_student = student.query.filter_by(email=email.data).first()
            if existing_student:
                raise ValidationError('This email is already registered. Please use a different one.')
