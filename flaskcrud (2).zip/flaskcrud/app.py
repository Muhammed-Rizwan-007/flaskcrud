# Install required packages
# pip install Flask Flask-WTF Flask-SQLAlchemy email-validator

# pip install flask flask-wtf email-validator 

from flask import Flask, render_template, redirect, url_for, flash
from models import db, student
from forms import RegistrationForm

app = Flask(__name__)
app.config['SECRET_KEY'] = 'your-secret-key-change-this'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///students.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db.init_app(app)

with app.app_context():
    db.create_all()

# 1. VIEW (Read all students)
@app.route('/')
def index():
    students = student.query.all()
    return render_template('index.html', students=students)

# 2. ADD (Create new student)
@app.route('/add', methods=['GET', 'POST'])
def add_student():
    form = RegistrationForm()
    if form.validate_on_submit():
        new_student = student(name=form.name.data, email=form.email.data)
        db.session.add(new_student)
        db.session.commit()
        flash('Student added successfully!')
        return redirect(url_for('index'))
    return render_template('register.html', form=form, title='Add Student')

# 3. MODIFY (Update existing student)
@app.route('/edit/<int:id>', methods=['GET', 'POST'])
def edit_student(id):
    target_student = student.query.get_or_404(id)
    form = RegistrationForm(original_email=target_student.email, obj=target_student)
    if form.validate_on_submit():
        target_student.name = form.name.data
        target_student.email = form.email.data
        db.session.commit()
        flash('Student updated successfully!')
        return redirect(url_for('index'))
    return render_template('register.html', form=form, title='Edit Student')

# 4. DELETE (Remove student via POST for security)
@app.route('/delete/<int:id>', methods=['POST'])
def delete_student(id):
    target_student = student.query.get_or_404(id)
    db.session.delete(target_student)
    db.session.commit()
    flash('Student deleted successfully!')
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True)
